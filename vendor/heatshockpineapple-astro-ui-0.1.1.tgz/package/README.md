# Heat Shock Pineapple Astro UI

The Hub, Portfolio, and Photography repositories consume this package for their header, footer, navigation, brand asset, mobile menu, and theme behavior. Page layouts, photography, scientific viewers, and decorative animations stay in their respective sites.

## Components

```astro
---
import Header from '@heatshockpineapple/astro-ui/Header.astro';
import Footer from '@heatshockpineapple/astro-ui/Footer.astro';
import ThemeInit from '@heatshockpineapple/astro-ui/ThemeInit.astro';
---
<!-- Put ThemeInit in head, before body content. -->
<ThemeInit defaultTheme="dark" />
<Header site="photography" />
<Footer variant="photography" email="photos@heatshockpineapple.com" />
```

Header site and Footer variant accept `hub`, `portfolio`, and `photography`. Footer exposes a `decoration` slot for the Portfolio sequence animation. Import the existing design-tokens stylesheet once in the consuming site's global stylesheet.

The local section links and hub Writing destination live in `src/config.js`. Writing currently points to the verified Substack profile; replace this one URL when a publication becomes available. Local section links remain unchanged. The brand logo returns to the hub; destination cards on the hub handle switching between sites. Shared headers and footers do not repeat those destinations.

## Theme contract

System, Light, and Dark share one implementation. A chosen preference is stored in the non-sensitive `hsp-theme` cookie for `heatshockpineapple.com` and its subdomains. Legacy `localStorage.theme` values remain readable. Cookie/localStorage failures do not prevent applying a theme in the current document. Photography defaults dark when no preference exists; the other sites default to the operating system. Explicit System overrides Photography's default.

The early head script and lifecycle listeners are installed once. The mobile menu closes on Escape, navigation, and desktop resize; traps keyboard focus while open; and restores the background's previous inert/scroll state. Theme controls work with regular page loads and Astro ClientRouter navigation.

## Versioned local distribution

This package is intentionally separate from the root CSS package. No registry publication is required for the first release. Each consumer checks an identical npm tarball into `vendor/` and uses a `file:vendor/heatshockpineapple-astro-ui-0.1.1.tgz` dependency. Its lockfile records the artifact's integrity. Builds do not depend on sibling repositories or an unpublished npm package.

For a subsequent release:

1. Edit and test this package; increment its version.
2. Run `npm test` from this directory.
3. Run `npm pack --ignore-scripts --pack-destination /path/to/release-directory`.
4. Copy the resulting tarball to each consumer's `vendor/`, install that path, and commit the tarball with both package manifests.
5. Build and preview all three sites before deploying. Retain old artifacts until no lockfile references them.

Consumers should not edit unpacked node_modules files. The same package can later be published to a registry without changing component imports. The root design-tokens package remains compatible with its existing Git dependency and CSS import paths; do not turn the root into a workspace that changes that installation contract.

## Validation

`npm test` runs Node's built-in test runner for the early theme runtime, storage failures, cookie scope, OS preference changes, navigation boundaries, and destination configuration. Consumer production builds validate Astro compilation. Browser checks must cover 320/390/desktop widths, both themes, menu keyboard behavior, route swaps, footer decoration, and PhotoSwipe.

Astro 5.16 is the tested peer range for this release. Framework/security upgrades are separate changes; do not widen compatibility without testing the consumers.
