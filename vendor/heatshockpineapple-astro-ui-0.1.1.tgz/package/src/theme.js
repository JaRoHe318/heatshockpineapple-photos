// This function is also serialized into the document head. Keep it self-contained.
export function initializeTheme() {
  if (window.HSPTheme) {
    window.HSPTheme.apply();
    return;
  }
  const valid = value => ['light', 'dark', 'system'].includes(value);
  const media = window.matchMedia('(prefers-color-scheme: dark)');
  let memory;
  const read = () => {
    if (valid(memory)) return memory;
    try {
      const cookie = document.cookie.split(';').map(part => part.trim()).find(part => part.startsWith('hsp-theme='));
      const value = cookie && cookie.slice('hsp-theme='.length);
      if (valid(value)) return value;
    } catch {}
    try {
      const stored = localStorage.getItem('theme');
      if (valid(stored)) return stored;
    } catch {}
    return null;
  };
  const apply = () => {
    const preference = read();
    const fallback = document.querySelector('meta[name="hsp-default-theme"]')?.content || 'system';
    const resolved = preference || (valid(fallback) ? fallback : 'system');
    const theme = resolved === 'system' ? (media.matches ? 'dark' : 'light') : resolved;
    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.style.colorScheme = theme;
    document.querySelectorAll('[data-hsp-theme-choice]').forEach(button => {
      button.setAttribute('aria-pressed', String(button.dataset.hspThemeChoice === resolved));
    });
  };
  const set = preference => {
    if (!valid(preference)) return;
    memory = preference;
    try { localStorage.setItem('theme', preference); } catch {}
    try {
      const shared = location.hostname === 'heatshockpineapple.com' || location.hostname.endsWith('.heatshockpineapple.com');
      document.cookie = 'hsp-theme=' + preference + '; Path=/; Max-Age=31536000; SameSite=Lax' +
        (shared ? '; Domain=heatshockpineapple.com' : '') + (location.protocol === 'https:' ? '; Secure' : '');
    } catch {}
    apply();
  };
  window.HSPTheme = { apply, set };
  document.addEventListener('astro:after-swap', apply);
  document.addEventListener('astro:page-load', apply);
  window.addEventListener('storage', () => { memory = null; apply(); });
  window.addEventListener('pageshow', () => { memory = null; apply(); });
  media.addEventListener('change', apply);
  apply();
}

export const themeBootstrap = `(${initializeTheme.toString()})();`;
