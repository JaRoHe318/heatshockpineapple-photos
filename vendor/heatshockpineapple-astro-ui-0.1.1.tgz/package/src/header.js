export function installHeader() {
  if (window.__hspHeaderInstalled) return;
  window.__hspHeaderInstalled = true;
  let restoreBackground = () => {};
  let restoreOverflow = '';
  let activeHeader = null;
  const desktop = window.matchMedia('(min-width: 901px)');

  const close = (restoreFocus = false) => {
    if (!activeHeader) return;
    const header = activeHeader;
    header.querySelector('[data-hsp-mobile-menu]').hidden = true;
    const button = header.querySelector('[data-hsp-menu-toggle]');
    button.setAttribute('aria-expanded', 'false');
    button.setAttribute('aria-label', 'Open navigation');
    restoreBackground();
    restoreBackground = () => {};
    document.body.style.overflow = restoreOverflow;
    activeHeader = null;
    if (restoreFocus) button.focus();
  };
  const open = header => {
    close();
    activeHeader = header;
    header.style.setProperty('--hsp-header-height', `${header.getBoundingClientRect().height}px`);
    header.querySelectorAll('details[open]').forEach(details => details.open = false);
    header.querySelector('[data-hsp-mobile-menu]').hidden = false;
    const button = header.querySelector('[data-hsp-menu-toggle]');
    button.setAttribute('aria-expanded', 'true');
    button.setAttribute('aria-label', 'Close navigation');
    restoreOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const siblings = [...document.body.children].filter(element => !element.contains(header) && !['SCRIPT','STYLE','LINK'].includes(element.tagName));
    const previous = siblings.map(element => [element, element.inert]);
    siblings.forEach(element => element.inert = true);
    restoreBackground = () => previous.forEach(([element, inert]) => element.inert = inert);
    header.querySelector('[data-hsp-mobile-menu] a')?.focus();
  };

  document.addEventListener('click', event => {
    if (!(event.target instanceof Element)) return;
    const toggle = event.target.closest('[data-hsp-menu-toggle]');
    if (toggle) {
      const header = toggle.closest('[data-hsp-header]');
      if (activeHeader === header) close(true); else open(header);
      return;
    }
    const choice = event.target.closest('[data-hsp-theme-choice]');
    if (choice) {
      window.HSPTheme?.set(choice.dataset.hspThemeChoice);
      const details = choice.closest('details');
      details.open = false;
      details.querySelector('summary')?.focus();
      return;
    }
    if (event.target.closest('[data-hsp-mobile-menu] a')) close();
    const panel = event.target.closest('[data-hsp-mobile-menu]');
    if (panel && (event.target === panel || event.target.tagName === 'NAV')) close(true);
    document.querySelectorAll('[data-hsp-theme-control][open]').forEach(details => {
      if (!details.contains(event.target)) details.open = false;
    });
  });

  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      const details = document.querySelector('[data-hsp-theme-control][open]');
      if (details) {
        details.open = false;
        details.querySelector('summary')?.focus();
      } else close(true);
      return;
    }
    if (event.key !== 'Tab' || !activeHeader) return;
    const controls = [...activeHeader.querySelectorAll('a[href],button,summary')].filter(element => element.getClientRects().length && !element.disabled);
    const first = controls[0];
    const last = controls[controls.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });
  document.addEventListener('astro:before-swap', () => close());
  document.addEventListener('astro:page-load', () => window.HSPTheme?.apply());
  desktop.addEventListener('change', () => { if (desktop.matches) close(); });
}
