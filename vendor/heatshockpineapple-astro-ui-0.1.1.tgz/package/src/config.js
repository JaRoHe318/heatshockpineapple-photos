export const BRAND_URL = 'https://heatshockpineapple.com';
export const WRITING_URL = 'https://substack.com/@heatshockpineapple';
export const SECTION_LINKS = Object.freeze({
  hub: [],
  photography: [
    { label: 'Home', href: '/' },
    { label: 'Gallery', href: '/gallery' },
    { label: 'Info', href: '/info' },
  ],
  portfolio: [
    { label: 'Home', href: '/' },
    { label: 'Science', href: '/science' },
    { label: 'Code', href: '/code' },
    { label: 'About', href: '/about' },
  ],
});

export function isSectionActive(pathname, href) {
  const path = pathname.replace(/\/+$/, '') || '/';
  return href === '/' ? path === '/' : path === href || path.startsWith(href + '/');
}
